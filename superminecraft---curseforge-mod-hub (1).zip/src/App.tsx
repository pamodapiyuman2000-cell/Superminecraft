import React, { useState, useEffect, useMemo } from 'react';
import {
  Flame,
  Search,
  Plus,
  SlidersHorizontal,
  Volume2,
  VolumeX,
  FileCode,
  Sparkles,
  Download,
  ShieldCheck,
  RefreshCw,
  Layers,
  Cpu,
  Compass,
  Zap,
} from 'lucide-react';
import { Project, ProjectCategory, ModLoader, SortOption } from './types';
import { INITIAL_PROJECTS } from './data/mockProjects';
import { EmberCanvas } from './components/EmberCanvas';
import { SplashScreen } from './components/SplashScreen';
import { ProjectCard } from './components/ProjectCard';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { CreateProjectModal } from './components/CreateProjectModal';
import { HtmlExportModal } from './components/HtmlExportModal';
import {
  playClickSound,
  playSuccessChime,
  toggleAudioMute,
  getIsAudioMuted,
} from './utils/audio';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem('superminecraft_projects');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return INITIAL_PROJECTS;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>('All');
  const [selectedVersion, setSelectedVersion] = useState<string>('All');
  const [selectedLoader, setSelectedLoader] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortOption>('downloads');

  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isHtmlExportOpen, setIsHtmlExportOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('superminecraft_projects', JSON.stringify(projects));
    } catch {
      // Ignore
    }
  }, [projects]);

  // Audio toggle
  const handleToggleMute = () => {
    const nextMuted = toggleAudioMute();
    setIsMuted(nextMuted);
    if (!nextMuted) {
      playClickSound();
    }
  };

  // Like / Heart
  const handleToggleLike = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === projectId) {
          const nextLiked = !p.isLiked;
          return {
            ...p,
            isLiked: nextLiked,
            likes: nextLiked ? p.likes + 1 : Math.max(0, p.likes - 1),
          };
        }
        return p;
      })
    );
    if (activeProject && activeProject.id === projectId) {
      setActiveProject((curr) =>
        curr
          ? {
              ...curr,
              isLiked: !curr.isLiked,
              likes: !curr.isLiked ? curr.likes + 1 : Math.max(0, curr.likes - 1),
            }
          : null
      );
    }
  };

  // Download increment
  const handleIncrementDownload = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === projectId ? { ...p, downloads: p.downloads + 1 } : p))
    );
    if (activeProject && activeProject.id === projectId) {
      setActiveProject((curr) => (curr ? { ...curr, downloads: curr.downloads + 1 } : null));
    }
  };

  // Add review
  const handleAddReview = (
    projectId: string,
    user: string,
    rating: number,
    comment: string
  ) => {
    const newReview = {
      id: 'rev-' + Date.now(),
      user,
      rating,
      date: 'Just now',
      comment,
    };
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === projectId) {
          return {
            ...p,
            reviews: [newReview, ...p.reviews],
          };
        }
        return p;
      })
    );
    if (activeProject && activeProject.id === projectId) {
      setActiveProject((curr) =>
        curr
          ? {
              ...curr,
              reviews: [newReview, ...curr.reviews],
            }
          : null
      );
    }
  };

  // Add newly created project
  const handleCreateProject = (newProject: Project) => {
    setProjects((prev) => [newProject, ...prev]);
    setActiveProject(newProject);
  };

  // Reset to default
  const handleResetData = () => {
    playClickSound();
    setProjects(INITIAL_PROJECTS);
    try {
      localStorage.removeItem('superminecraft_projects');
    } catch {
      // Ignore
    }
    playSuccessChime();
  };

  // Filtering & Sorting
  const filteredProjects = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return projects
      .filter((p) => {
        const matchesCategory =
          selectedCategory === 'All' || p.category === selectedCategory;
        const matchesQuery =
          !query ||
          p.title.toLowerCase().includes(query) ||
          p.summary.toLowerCase().includes(query) ||
          p.author.toLowerCase().includes(query) ||
          p.tags.some((t) => t.toLowerCase().includes(query));
        const matchesVersion =
          selectedVersion === 'All' ||
          p.minecraftVersions.some((v) => v.startsWith(selectedVersion));
        const matchesLoader =
          selectedLoader === 'All' ||
          p.loaders.includes(selectedLoader as ModLoader);

        return matchesCategory && matchesQuery && matchesVersion && matchesLoader;
      })
      .sort((a, b) => {
        if (sortBy === 'downloads') return b.downloads - a.downloads;
        if (sortBy === 'rating') return b.likes - a.likes;
        if (sortBy === 'name') return a.title.localeCompare(b.title);
        return 0;
      });
  }, [projects, searchQuery, selectedCategory, selectedVersion, selectedLoader, sortBy]);

  // Aggregate stats
  const totalDownloads = useMemo(
    () => projects.reduce((acc, curr) => acc + curr.downloads, 0),
    [projects]
  );

  const formatLargeNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M+';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K+';
    return num.toString();
  };

  const categories: { id: ProjectCategory; label: string; icon: string }[] = [
    { id: 'All', label: 'All Categories', icon: '📁' },
    { id: 'Mod', label: 'Mods', icon: '📦' },
    { id: 'Resource Pack', label: 'Resource Packs', icon: '🎨' },
    { id: 'Shader', label: 'Shaders', icon: '✨' },
    { id: 'Modpack', label: 'Modpacks', icon: '⚔️' },
  ];

  return (
    <div className="minecraft-pure-bg text-stone-100 min-h-screen font-sans selection:bg-orange-500 selection:text-stone-950 flex flex-col justify-between relative overflow-x-hidden">
      {/* Floating Ember Particle Atmosphere Canvas */}
      <EmberCanvas />

      {/* Splash Screen Intro */}
      {showSplash && (
        <SplashScreen
          onEnter={() => {
            setShowSplash(false);
          }}
        />
      )}

      {/* Dark Ambient Overlay for crisp contrast */}
      <div className="dark-overlay relative z-10 flex flex-col justify-between flex-1 w-full">
        {/* TOP BAR / NAVIGATION */}
        <header className="border-b border-stone-800/80 bg-[#120e0b]/95 backdrop-blur-md px-4 sm:px-6 py-3.5 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            {/* Left Zone: Brand + Creator attribution */}
            <div className="flex items-center gap-4 sm:gap-6">
              <div
                onClick={() => {
                  playClickSound();
                  setSelectedCategory('All');
                  setSearchQuery('');
                }}
                className="flex items-center gap-3 cursor-pointer group"
              >
                <div className="h-10 w-10 bg-gradient-to-br from-orange-500 via-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-orange-500/25 group-hover:scale-105 transition-transform duration-200 border border-orange-400/40">
                  🔥
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white group-hover:text-orange-400 transition-colors">
                      SuperMinecraft
                    </span>
                  </div>
                  <span className="text-[10px] font-mono tracking-widest text-orange-400 uppercase block -mt-0.5">
                    CurseForge Mod Hub
                  </span>
                </div>
              </div>

              {/* Creators Attribution Tagline */}
              <div className="hidden xl:flex items-center gap-2 text-xs border-l border-stone-800/80 pl-5 text-stone-400 font-mono">
                <span>By:</span>
                <span className="text-purple-400 font-bold hover:underline cursor-default">Nightbrone</span>
                <span>•</span>
                <span className="text-emerald-400 font-bold hover:underline cursor-default">Didula48</span>
                <span>•</span>
                <span className="text-amber-400 font-bold hover:underline cursor-default">voidstriker</span>
              </div>
            </div>

            {/* Middle Zone: Search Bar */}
            <div className="flex-1 max-w-md mx-2 sm:mx-6">
              <div className="relative">
                <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search mods, resource packs, shaders..."
                  className="w-full bg-[#181512]/90 border border-stone-700/70 hover:border-stone-600 focus:border-orange-500 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-orange-500/50 transition"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-white cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Right Zone: Primary Actions */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Sound Toggle */}
              <button
                onClick={handleToggleMute}
                title={isMuted ? 'Unmute synthesized sound effects' : 'Mute sound effects'}
                className="p-2 text-stone-400 hover:text-orange-400 bg-stone-900/80 hover:bg-stone-800 border border-stone-800 rounded-xl transition cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-orange-400" />}
              </button>

              {/* Standalone HTML Export / Code Viewer */}
              <button
                onClick={() => {
                  playClickSound();
                  setIsHtmlExportOpen(true);
                }}
                className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-stone-900/90 hover:bg-stone-800 border border-stone-700/80 text-stone-300 hover:text-white rounded-xl text-xs font-semibold transition cursor-pointer"
                title="View and download standalone single-file HTML"
              >
                <FileCode className="w-4 h-4 text-orange-400" />
                <span>Export HTML</span>
              </button>

              {/* Replay Intro */}
              <button
                onClick={() => {
                  playClickSound();
                  setShowSplash(true);
                }}
                className="hidden lg:flex items-center gap-1.5 px-3 py-2 text-stone-400 hover:text-stone-200 text-xs font-medium cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Intro</span>
              </button>

              {/* Create Project Button */}
              <button
                onClick={() => {
                  playClickSound();
                  setIsCreateOpen(true);
                }}
                className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-stone-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 transition transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-4 h-4 font-black" />
                <span>Create Project</span>
              </button>
            </div>
          </div>
        </header>

        {/* HERO SPOTLIGHT & PLATFORM STATS */}
        <section className="max-w-7xl w-full mx-auto px-4 sm:px-6 pt-6 pb-2">
          {/* Spotlight Banner Card */}
          <div className="relative bg-gradient-to-r from-orange-950/40 via-stone-900/90 to-[#191512]/90 border border-orange-500/30 rounded-2xl p-5 sm:p-7 shadow-2xl overflow-hidden mb-6">
            <div className="absolute -right-12 -top-12 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-orange-400 bg-orange-500/20 border border-orange-500/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <Zap className="w-3 h-3 text-orange-400 inline" />
                    Spotlight Modpack of the Week
                  </span>
                  <span className="text-xs text-stone-400 font-mono">1.21.1 Tricky Trials</span>
                </div>
                <h2 className="text-xl sm:text-3xl font-black text-white tracking-tight">
                  SuperMinecraft AdventureCraft 2026
                </h2>
                <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                  Curated by <strong className="text-purple-300">Nightbrone</strong>,{' '}
                  <strong className="text-emerald-300">Didula48</strong> &{' '}
                  <strong className="text-amber-300">voidstriker</strong>. Packed with 180 mods, 45 custom quests, shaders pre-configured, and butter-smooth FPS.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  onClick={() => {
                    const spotlight = projects.find((p) => p.id === 'super-adventure-pack');
                    if (spotlight) {
                      playClickSound();
                      setActiveProject(spotlight);
                    }
                  }}
                  className="px-5 py-2.5 bg-orange-500 hover:bg-orange-400 text-stone-950 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-orange-500/20 transition flex items-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  View & Install
                </button>
              </div>
            </div>
          </div>

          {/* Quick Stats Pill Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#171412]/80 border border-stone-800/80 rounded-xl p-3 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10 text-orange-400">
                <Download className="w-4 h-4" />
              </div>
              <div>
                <div className="text-base sm:text-lg font-black text-white tabular-nums">
                  {formatLargeNumber(totalDownloads)}
                </div>
                <div className="text-[11px] text-stone-400">Total Downloads</div>
              </div>
            </div>

            <div className="bg-[#171412]/80 border border-stone-800/80 rounded-xl p-3 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-base sm:text-lg font-black text-white tabular-nums">
                  {projects.length} Verified
                </div>
                <div className="text-[11px] text-stone-400">Active Mod Releases</div>
              </div>
            </div>

            <div className="bg-[#171412]/80 border border-stone-800/80 rounded-xl p-3 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <div className="text-base sm:text-lg font-black text-white">100% Clean</div>
                <div className="text-[11px] text-stone-400">Malware & JAR Verified</div>
              </div>
            </div>

            <div className="bg-[#171412]/80 border border-stone-800/80 rounded-xl p-3 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
                <Compass className="w-4 h-4" />
              </div>
              <div>
                <div className="text-base sm:text-lg font-black text-white">Forge & Fabric</div>
                <div className="text-[11px] text-stone-400">+ NeoForge & Quilt</div>
              </div>
            </div>
          </div>
        </section>

        {/* MAIN EXPLORER GRID */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* SIDEBAR FILTERS */}
          <aside className="space-y-4 lg:col-span-1">
            {/* Categories */}
            <div className="bg-[#171412]/90 border border-stone-800/80 p-5 rounded-2xl space-y-4 shadow-xl">
              <h3 className="font-bold text-xs uppercase tracking-wider text-orange-400 flex items-center justify-between">
                <span>Browse Categories</span>
                <span className="text-[10px] text-stone-400 font-mono">
                  {filteredProjects.length} listed
                </span>
              </h3>

              <div className="space-y-1.5 flex flex-col">
                {categories.map((cat) => {
                  const isActive = selectedCategory === cat.id;
                  const count =
                    cat.id === 'All'
                      ? projects.length
                      : projects.filter((p) => p.category === cat.id).length;

                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        playClickSound();
                        setSelectedCategory(cat.id);
                      }}
                      className={`text-left text-xs font-semibold py-2 px-3 rounded-xl flex items-center justify-between transition cursor-pointer ${
                        isActive
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40 shadow-sm'
                          : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900 border border-transparent'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{cat.icon}</span>
                        <span>{cat.label}</span>
                      </span>
                      <span className="text-[10px] text-stone-400 font-mono bg-stone-950/60 px-1.5 py-0.5 rounded">
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Version filter */}
              <div className="pt-4 border-t border-stone-800/80 space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" />
                  Minecraft Version
                </label>
                <select
                  value={selectedVersion}
                  onChange={(e) => {
                    playClickSound();
                    setSelectedVersion(e.target.value);
                  }}
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl p-2.5 text-xs text-stone-200 focus:outline-none focus:border-orange-500"
                >
                  <option value="All">All Game Versions</option>
                  <option value="1.21">Minecraft 1.21.x (Tricky Trials)</option>
                  <option value="1.20">Minecraft 1.20.x (Trails & Tales)</option>
                  <option value="1.19">Minecraft 1.19.x (Wild Update)</option>
                  <option value="1.16">Minecraft 1.16.5 (Nether Update)</option>
                </select>
              </div>

              {/* Loader filter */}
              <div className="pt-2 space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-wider text-stone-400 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-amber-400" />
                  Mod Loader Engine
                </label>
                <select
                  value={selectedLoader}
                  onChange={(e) => {
                    playClickSound();
                    setSelectedLoader(e.target.value);
                  }}
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl p-2.5 text-xs text-stone-200 focus:outline-none focus:border-orange-500"
                >
                  <option value="All">All Mod Loaders</option>
                  <option value="Forge">Forge</option>
                  <option value="Fabric">Fabric</option>
                  <option value="NeoForge">NeoForge</option>
                  <option value="Quilt">Quilt</option>
                </select>
              </div>

              {/* Reset Data button */}
              <div className="pt-3 border-t border-stone-800/80">
                <button
                  onClick={handleResetData}
                  className="w-full py-2 text-[11px] text-stone-400 hover:text-stone-300 hover:bg-stone-900 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  Reset to Default Mods
                </button>
              </div>
            </div>
          </aside>

          {/* DYNAMIC CARD CONTENT FEED */}
          <section className="lg:col-span-3 space-y-4">
            {/* Filter Status & Sort Header */}
            <div className="bg-[#171412]/90 border border-stone-800/80 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-400">Showing:</span>
                <span className="text-xs font-bold text-white">
                  {filteredProjects.length}{' '}
                  {filteredProjects.length === 1 ? 'Project' : 'Projects'}
                </span>
                {selectedCategory !== 'All' && (
                  <span className="text-[11px] text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                    in {selectedCategory}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs text-stone-400 font-mono flex items-center gap-1">
                  <SlidersHorizontal className="w-3 h-3 text-stone-400" />
                  Sort By:
                </span>
                <select
                  value={sortBy}
                  onChange={(e) => {
                    playClickSound();
                    setSortBy(e.target.value as SortOption);
                  }}
                  className="bg-stone-950 border border-stone-800 rounded-xl px-3 py-1.5 text-xs text-stone-200 focus:outline-none focus:border-orange-500"
                >
                  <option value="downloads">Most Downloads</option>
                  <option value="rating">Highest Rated / Likes</option>
                  <option value="name">Name (A-Z)</option>
                </select>
              </div>
            </div>

            {/* Project Cards Loop */}
            {filteredProjects.length === 0 ? (
              <div className="bg-[#171412]/60 border border-stone-800 rounded-2xl p-12 text-center space-y-3">
                <div className="text-4xl">🔍</div>
                <h4 className="text-base font-bold text-white">No projects found</h4>
                <p className="text-xs text-stone-400 max-w-sm mx-auto">
                  Try adjusting your search query, Minecraft version, or category filter to discover more creations.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedVersion('All');
                    setSelectedLoader('All');
                  }}
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-orange-400 border border-stone-700 rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredProjects.map((project) => (
                  <ProjectCard
                    key={project.id}
                    project={project}
                    onSelect={(p) => setActiveProject(p)}
                    onToggleLike={handleToggleLike}
                    onIncrementDownload={handleIncrementDownload}
                  />
                ))}
              </div>
            )}
          </section>
        </main>

        {/* FOOTER */}
        <footer className="border-t border-stone-800/80 bg-[#120e0b]/95 text-stone-400 py-8 px-6 mt-12">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <span className="text-lg">🔥</span>
              <div>
                <p className="text-stone-300 font-semibold">
                  © 2026 SuperMinecraft. CurseForge Inspired Mod Hub.
                </p>
                <p className="text-stone-400 text-[11px]">
                  Created and engineered by{' '}
                  <strong className="text-purple-400 font-semibold">Nightbrone</strong>,{' '}
                  <strong className="text-emerald-400 font-semibold">Didula48</strong> &{' '}
                  <strong className="text-amber-400 font-semibold">voidstriker</strong>.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-stone-400">
              <button
                onClick={() => setIsHtmlExportOpen(true)}
                className="hover:text-orange-400 transition cursor-pointer flex items-center gap-1 font-semibold"
              >
                <FileCode className="w-3.5 h-3.5" /> Standalone HTML Export
              </button>
              <span>·</span>
              <button
                onClick={() => setShowSplash(true)}
                className="hover:text-stone-200 transition cursor-pointer"
              >
                Intro Screen
              </button>
              <span>·</span>
              <button
                onClick={() => setIsCreateOpen(true)}
                className="hover:text-orange-400 transition cursor-pointer"
              >
                Upload Project
              </button>
            </div>
          </div>
        </footer>
      </div>

      {/* MODALS */}
      {/* 1. Project Detail Modal */}
      {activeProject && (
        <ProjectDetailModal
          project={activeProject}
          onClose={() => setActiveProject(null)}
          onToggleLike={handleToggleLike}
          onIncrementDownload={handleIncrementDownload}
          onAddReview={handleAddReview}
        />
      )}

      {/* 2. Create Project Modal */}
      {isCreateOpen && (
        <CreateProjectModal
          onClose={() => setIsCreateOpen(false)}
          onCreate={handleCreateProject}
        />
      )}

      {/* 3. Standalone HTML Export Modal */}
      {isHtmlExportOpen && (
        <HtmlExportModal onClose={() => setIsHtmlExportOpen(false)} />
      )}
    </div>
  );
}
