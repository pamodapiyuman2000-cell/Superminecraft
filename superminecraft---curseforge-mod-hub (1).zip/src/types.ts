export type ProjectCategory = 'All' | 'Mod' | 'Resource Pack' | 'Shader' | 'Modpack';

export type ModLoader = 'Forge' | 'Fabric' | 'NeoForge' | 'Quilt';

export interface ProjectVersionFile {
  id: string;
  versionName: string;
  gameVersion: string;
  loader: ModLoader[];
  releaseType: 'Release' | 'Beta' | 'Alpha';
  fileSize: string;
  uploadDate: string;
  downloads: number;
  fileName: string;
}

export interface ProjectChangelog {
  version: string;
  date: string;
  notes: string[];
}

export interface ProjectReview {
  id: string;
  user: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Project {
  id: string;
  title: string;
  category: 'Mod' | 'Resource Pack' | 'Shader' | 'Modpack';
  summary: string;
  description: string;
  author: string;
  downloads: number;
  likes: number;
  isLiked?: boolean;
  icon: string;
  bannerColor: string;
  minecraftVersions: string[];
  loaders: ModLoader[];
  lastUpdated: string;
  fileSize: string;
  tags: string[];
  installCommand?: string;
  files: ProjectVersionFile[];
  changelog: ProjectChangelog[];
  reviews: ProjectReview[];
}

export type SortOption = 'downloads' | 'rating' | 'recent' | 'name';
