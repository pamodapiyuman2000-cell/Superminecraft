import React, { useState } from 'react';
import { X, Copy, Download, Check, FileCode, Sparkles } from 'lucide-react';
import { playClickSound, playSuccessChime } from '../utils/audio';

interface HtmlExportModalProps {
  onClose: () => void;
}

export const HtmlExportModal: React.FC<HtmlExportModalProps> = ({ onClose }) => {
  const [copied, setCopied] = useState(false);

  // Standalone production-ready single file HTML with full Tailwind, Ember Canvas, dynamic cards, modals, and CurseForge styling
  const standaloneHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SuperMinecraft - CurseForge Style Platform</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Rajdhani:wght@600;700&display=swap" rel="stylesheet">
  <style>
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(24px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in { animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
    .delay-1 { animation-delay: 0.15s; }
    .delay-2 { animation-delay: 0.35s; }
    .delay-3 { animation-delay: 0.55s; }
    .delay-button { animation-delay: 0.8s; }

    /* Minecraft Dirt / Deepslate Procedural Grid Texture */
    .minecraft-pure-bg {
      background-color: #120e0b;
      background-image: 
        radial-gradient(circle at 50% 20%, rgba(249, 115, 22, 0.12) 0%, transparent 60%),
        linear-gradient(rgba(0,0,0,0.65) 100%, transparent 100%),
        linear-gradient(90deg, #1c140e 25%, transparent 25%),
        linear-gradient(#1c140e 25%, transparent 25%),
        linear-gradient(90deg, #2b1f16 50%, transparent 50%),
        linear-gradient(#2b1f16 50%, transparent 50%);
      background-size: 100% 100%, 100% 100%, 64px 64px, 64px 64px, 32px 32px, 32px 32px;
      background-attachment: fixed;
    }

    .dark-overlay {
      background: linear-gradient(to bottom, rgba(14, 10, 8, 0.92), rgba(6, 4, 3, 0.98));
      min-height: 100vh;
    }

    ::-webkit-scrollbar { width: 8px; }
    ::-webkit-scrollbar-track { background: #0c0a09; }
    ::-webkit-scrollbar-thumb { background: #292524; border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: #f97316; }
  </style>
</head>
<body class="minecraft-pure-bg text-stone-100 min-h-screen font-sans selection:bg-orange-500 selection:text-stone-950 flex flex-col justify-between">

  <!-- Ambient Floating Embers Canvas -->
  <canvas id="ember-canvas" class="pointer-events-none fixed inset-0 z-0 h-full w-full opacity-60 mix-blend-screen"></canvas>

  <div class="dark-overlay relative z-10 flex flex-col justify-between flex-1 w-full">

    <!-- SPLASH SCREEN / INTRO PAGE -->
    <div id="splash-screen" class="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#070504] px-4 transition-all duration-700">
      <div class="relative z-10 text-center max-w-2xl mx-auto space-y-6">
        <div class="w-20 h-20 mx-auto bg-gradient-to-br from-orange-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-xl shadow-orange-500/30 text-4xl opacity-0 animate-fade-in">
          🔥
        </div>
        
        <h2 class="text-xs font-mono uppercase tracking-[0.35em] text-orange-400 font-bold opacity-0 animate-fade-in delay-1">
          ✦ Created By ✦
        </h2>
        
        <h1 class="text-3xl sm:text-5xl md:text-6xl font-black tracking-tight flex flex-wrap items-center justify-center gap-2 sm:gap-4 text-white">
          <span class="opacity-0 animate-fade-in delay-1 bg-gradient-to-r from-purple-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">Nightbrone</span>
          <span class="text-stone-600 hidden sm:inline">•</span>
          <span class="opacity-0 animate-fade-in delay-2 bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent">Didula48</span>
          <span class="text-stone-600 hidden sm:inline">•</span>
          <span class="opacity-0 animate-fade-in delay-3 bg-gradient-to-r from-amber-400 via-orange-300 to-amber-400 bg-clip-text text-transparent">voidstriker</span>
        </h1>
        
        <p class="text-sm sm:text-base text-stone-300 max-w-md mx-auto opacity-0 animate-fade-in delay-3">
          Next-generation CurseForge inspired database hub for Minecraft mods, resource packs & shaders.
        </p>
        
        <div class="pt-4 opacity-0 animate-fade-in delay-button">
          <button onclick="enterDashboard()" class="px-8 py-3.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-stone-950 font-extrabold text-base rounded-xl shadow-lg shadow-orange-500/30 transform hover:-translate-y-1 transition-all cursor-pointer">
            Explore SuperMinecraft →
          </button>
        </div>
      </div>
    </div>

    <!-- MAIN PLATFORM INTERFACE -->
    <div id="app-content" class="hidden min-h-screen flex flex-col w-full">
      <!-- NAVIGATION BAR -->
      <nav class="border-b border-stone-800 bg-[#141210]/95 backdrop-blur-md px-6 py-3.5 sticky top-0 z-40 flex items-center justify-between">
        <div class="flex items-center gap-6">
          <div class="flex items-center gap-3 cursor-pointer" onclick="location.reload()">
            <div class="h-9 w-9 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl flex items-center justify-center text-lg shadow-md shadow-orange-500/20">
              🔥
            </div>
            <div>
              <span class="font-extrabold text-lg tracking-tight text-white block">SuperMinecraft</span>
              <span class="text-[10px] text-orange-400 font-mono tracking-wider">CURSEFORGE HUB</span>
            </div>
          </div>
          
          <div class="hidden lg:flex items-center gap-2 text-xs border-l border-stone-800 pl-6 text-stone-400 font-mono">
            <span>By:</span>
            <span class="text-purple-400 font-semibold">Nightbrone</span> • 
            <span class="text-emerald-400 font-semibold">Didula48</span> • 
            <span class="text-amber-400 font-semibold">voidstriker</span>
          </div>
        </div>
        
        <!-- SEARCH BAR -->
        <div class="flex-1 max-w-md mx-4 sm:mx-8">
          <input type="text" id="search-bar" oninput="filterProjects()" placeholder="Search mods, resource packs, shaders..." class="w-full bg-stone-900/90 border border-stone-700/80 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-orange-500 text-stone-100 placeholder-stone-500">
        </div>

        <div class="flex items-center gap-3">
          <button onclick="openUploadModal()" class="flex items-center gap-1.5 px-3.5 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold text-xs rounded-lg transition shadow-md shadow-orange-500/20 cursor-pointer">
            <span class="text-base font-black">+</span> Create Project
          </button>
        </div>
      </nav>

      <!-- MAIN CONTAINER -->
      <main class="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
        <!-- SIDEBAR -->
        <aside class="space-y-4 lg:col-span-1">
          <div class="bg-[#171412]/90 border border-stone-800 p-5 rounded-2xl space-y-4 shadow-xl">
            <h3 class="font-bold text-xs uppercase tracking-wider text-orange-400">Browse Categories</h3>
            <div class="space-y-1.5 flex flex-col">
              <button onclick="setCategoryFilter('All')" id="cat-All" class="text-left text-xs font-semibold py-2 px-3 rounded-lg bg-orange-500/15 text-orange-400 border border-orange-500/30 transition">📁 All Categories</button>
              <button onclick="setCategoryFilter('Mod')" id="cat-Mod" class="text-left text-xs font-medium py-2 px-3 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-900 transition">📦 Mods</button>
              <button onclick="setCategoryFilter('Resource Pack')" id="cat-Resource Pack" class="text-left text-xs font-medium py-2 px-3 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-900 transition">🎨 Resource Packs</button>
              <button onclick="setCategoryFilter('Shader')" id="cat-Shader" class="text-left text-xs font-medium py-2 px-3 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-900 transition">✨ Shaders</button>
              <button onclick="setCategoryFilter('Modpack')" id="cat-Modpack" class="text-left text-xs font-medium py-2 px-3 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-900 transition">⚔️ Modpacks</button>
            </div>

            <div class="pt-4 border-t border-stone-800">
              <h4 class="font-bold text-[11px] uppercase tracking-wider text-stone-400 mb-2">Minecraft Version</h4>
              <select id="version-filter" onchange="filterProjects()" class="w-full bg-stone-950 border border-stone-800 rounded-lg p-2 text-xs text-stone-300 focus:outline-none focus:border-orange-500">
                <option value="All">All Versions</option>
                <option value="1.21.1">Minecraft 1.21.1</option>
                <option value="1.20.4">Minecraft 1.20.4</option>
                <option value="1.19.2">Minecraft 1.19.2</option>
                <option value="1.16.5">Minecraft 1.16.5</option>
              </select>
            </div>
          </div>
        </aside>

        <!-- CONTENT SECTION -->
        <section class="lg:col-span-3 space-y-4">
          <!-- SORT BAR -->
          <div class="bg-[#171412]/90 border border-stone-800 p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl">
            <div class="flex items-center gap-2">
              <span class="text-xs text-stone-400">Showing:</span>
              <span id="project-count" class="text-xs font-bold text-white">0 Projects</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-xs text-stone-400 font-mono">Sort By:</span>
              <select id="sort-filter" onchange="filterProjects()" class="bg-stone-950 border border-stone-800 rounded-lg px-3 py-1.5 text-xs text-stone-300 focus:outline-none focus:border-orange-500">
                <option value="downloads">Most Downloads</option>
                <option value="likes">Highest Rated / Likes</option>
                <option value="name">Name (A-Z)</option>
              </select>
            </div>
          </div>

          <!-- PROJECT CARDS -->
          <div id="cards-container" class="space-y-4"></div>
        </section>
      </main>

      <footer class="border-t border-stone-800/80 bg-[#120e0b]/95 text-center py-6 text-xs text-stone-400">
        <p>© 2026 SuperMinecraft. Curated and developed by <span class="text-stone-300 font-bold">Nightbrone, Didula48 & voidstriker</span>.</p>
      </footer>
    </div>

    <!-- MODAL: CREATE PROJECT -->
    <div id="upload-modal" class="fixed inset-0 z-50 hidden items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div class="bg-[#171412] border border-stone-800 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
        <div class="flex items-center justify-between border-b border-stone-800 pb-3">
          <h3 class="font-bold text-base text-white">Create New Project</h3>
          <button onclick="closeUploadModal()" class="text-stone-400 hover:text-white">✕</button>
        </div>
        <form onsubmit="submitNewProject(event)" class="space-y-3 text-xs">
          <div>
            <label class="block text-stone-300 font-semibold mb-1">Title *</label>
            <input type="text" id="m-title" required class="w-full bg-stone-950 border border-stone-800 rounded p-2 text-stone-100" placeholder="e.g. Enderite Armour & Weapons">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-stone-300 font-semibold mb-1">Category</label>
              <select id="m-cat" class="w-full bg-stone-950 border border-stone-800 rounded p-2 text-stone-100">
                <option value="Mod">Mod</option>
                <option value="Resource Pack">Resource Pack</option>
                <option value="Shader">Shader</option>
                <option value="Modpack">Modpack</option>
              </select>
            </div>
            <div>
              <label class="block text-stone-300 font-semibold mb-1">Author</label>
              <input type="text" id="m-author" value="Nightbrone" class="w-full bg-stone-950 border border-stone-800 rounded p-2 text-stone-100">
            </div>
          </div>
          <div>
            <label class="block text-stone-300 font-semibold mb-1">Summary *</label>
            <input type="text" id="m-summary" required class="w-full bg-stone-950 border border-stone-800 rounded p-2 text-stone-100" placeholder="A brief one line description...">
          </div>
          <div class="flex justify-end gap-2 pt-2 border-t border-stone-800">
            <button type="button" onclick="closeUploadModal()" class="px-4 py-2 bg-stone-900 text-stone-400 rounded">Cancel</button>
            <button type="submit" class="px-4 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold rounded">Publish</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    // Ember particle animation
    const canvas = document.getElementById('ember-canvas');
    if (canvas) {
      const ctx = canvas.getContext('2d');
      let w = canvas.width = window.innerWidth;
      let h = canvas.height = window.innerHeight;
      window.onresize = () => { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; };
      const particles = Array.from({length: 40}, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        s: 1.5 + Math.random() * 2.5,
        sy: 0.6 + Math.random() * 1.2,
        sx: (Math.random() - 0.5) * 0.5,
        o: 0.2 + Math.random() * 0.6
      }));
      function loop() {
        ctx.clearRect(0,0,w,h);
        particles.forEach(p => {
          p.y -= p.sy; p.x += p.sx;
          if (p.y < 0) { p.y = h + 10; p.x = Math.random() * w; }
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.s, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(249, 115, 22, ' + p.o + ')';
          ctx.shadowBlur = 6;
          ctx.shadowColor = '#f97316';
          ctx.fill();
        });
        requestAnimationFrame(loop);
      }
      loop();
    }

    // Projects database
    let projects = [
      { id: '1', title: 'Create: Steam & Rails', category: 'Mod', author: 'Nightbrone & Team', downloads: 38400000, likes: 42100, icon: '🚂', summary: 'The ultimate train and railway engineering mod for Create.', version: '1.21.1', size: '14.8 MB' },
      { id: '2', title: 'Complementary Shaders', category: 'Shader', author: 'voidstriker', downloads: 52100000, likes: 89400, icon: '✨', summary: 'Exceptional performance, volumetric clouds, colored lighting and auroras.', version: '1.21.1', size: '4.2 MB' },
      { id: '3', title: 'Faithful 64x Deluxe Pack', category: 'Resource Pack', author: 'Didula48 & Community', downloads: 41900000, likes: 31200, icon: '🎨', summary: 'Double-resolution Minecraft texture pack strictly faithful to vanilla.', version: '1.21.1', size: '32.1 MB' },
      { id: '4', title: 'SuperMinecraft AdventureCraft', category: 'Modpack', author: 'Nightbrone, Didula48 & voidstriker', downloads: 14200000, likes: 61800, icon: '⚔️', summary: 'The flagship curated 180-mod adventure experience with quests and shaders.', version: '1.21.1', size: '248 MB' },
      { id: '5', title: "Farmer's Delight Culinary", category: 'Mod', author: 'Didula48', downloads: 64100000, likes: 72400, icon: '🍲', summary: 'Gently expands farming and cooking with pots, skillets, and organic soil.', version: '1.20.4', size: '6.7 MB' }
    ];

    let currentCategory = 'All';

    function enterDashboard() {
      const splash = document.getElementById('splash-screen');
      splash.style.opacity = '0';
      setTimeout(() => {
        splash.style.display = 'none';
        document.getElementById('app-content').classList.remove('hidden');
        renderCards();
      }, 500);
    }

    function setCategoryFilter(cat) {
      currentCategory = cat;
      document.querySelectorAll('#cat-All, #cat-Mod, #cat-Resource\\\\ Pack, #cat-Shader, #cat-Modpack').forEach(b => {
        b.className = 'text-left text-xs font-medium py-2 px-3 rounded-lg text-stone-400 hover:text-stone-200 hover:bg-stone-900 transition';
      });
      const activeBtn = document.getElementById('cat-' + cat);
      if (activeBtn) {
        activeBtn.className = 'text-left text-xs font-semibold py-2 px-3 rounded-lg bg-orange-500/15 text-orange-400 border border-orange-500/30 transition';
      }
      filterProjects();
    }

    function filterProjects() {
      const query = (document.getElementById('search-bar').value || '').toLowerCase();
      const version = document.getElementById('version-filter').value;
      const sort = document.getElementById('sort-filter').value;

      let list = projects.filter(p => {
        const matchesCat = currentCategory === 'All' || p.category === currentCategory;
        const matchesQuery = p.title.toLowerCase().includes(query) || p.summary.toLowerCase().includes(query) || p.author.toLowerCase().includes(query);
        const matchesVersion = version === 'All' || p.version === version;
        return matchesCat && matchesQuery && matchesVersion;
      });

      if (sort === 'downloads') list.sort((a,b) => b.downloads - a.downloads);
      if (sort === 'likes') list.sort((a,b) => b.likes - a.likes);
      if (sort === 'name') list.sort((a,b) => a.title.localeCompare(b.title));

      renderCards(list);
    }

    function renderCards(list = projects) {
      const container = document.getElementById('cards-container');
      const countEl = document.getElementById('project-count');
      if (countEl) countEl.innerText = list.length + ' Projects';

      if (list.length === 0) {
        container.innerHTML = '<div class="p-8 text-center text-stone-500 bg-stone-900/40 rounded-2xl border border-stone-800">No projects found matching your query.</div>';
        return;
      }

      container.innerHTML = list.map(p => \`
        <div class="bg-[#171412]/90 border border-stone-800/80 hover:border-orange-500/50 rounded-2xl p-4 sm:p-5 transition shadow-lg hover:shadow-orange-500/10 flex flex-col sm:flex-row items-start gap-4">
          <div class="w-16 h-16 rounded-xl bg-stone-900 border border-stone-700/60 flex items-center justify-center text-3xl shrink-0">
            \${p.icon}
          </div>
          <div class="flex-1 min-w-0 space-y-1.5 w-full">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <h4 class="font-bold text-base text-white">\${p.title}</h4>
                <span class="text-[10px] font-semibold px-2 py-0.5 rounded bg-orange-500/10 text-orange-400 border border-orange-500/20">\${p.category}</span>
              </div>
              <button onclick="likeProject('\${p.id}')" class="text-xs text-rose-400 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20">❤️ \${p.likes}</button>
            </div>
            <p class="text-xs text-stone-400">By <strong class="text-stone-300">\${p.author}</strong> · MC \${p.version} · \${p.size}</p>
            <p class="text-xs text-stone-300 line-clamp-2">\${p.summary}</p>
            <div class="pt-2 flex items-center justify-between border-t border-stone-800/60">
              <span class="text-xs font-mono text-stone-400">📥 \${(p.downloads/1000000).toFixed(1)}M downloads</span>
              <button onclick="downloadMock('\${p.id}', this)" class="px-3 py-1 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold text-xs rounded transition">Download</button>
            </div>
          </div>
        </div>
      \`).join('');
    }

    function likeProject(id) {
      const p = projects.find(x => x.id === id);
      if (p) { p.likes++; filterProjects(); }
    }

    function downloadMock(id, btn) {
      const p = projects.find(x => x.id === id);
      if (p) {
        p.downloads += 1;
        btn.innerText = 'Downloading...';
        setTimeout(() => {
          btn.innerText = 'Installed!';
          btn.classList.remove('bg-orange-500');
          btn.classList.add('bg-emerald-600', 'text-white');
          setTimeout(() => {
            btn.innerText = 'Download';
            btn.classList.remove('bg-emerald-600', 'text-white');
            btn.classList.add('bg-orange-500');
            filterProjects();
          }, 2000);
        }, 1000);
      }
    }

    function openUploadModal() {
      document.getElementById('upload-modal').classList.remove('hidden');
      document.getElementById('upload-modal').classList.add('flex');
    }

    function closeUploadModal() {
      document.getElementById('upload-modal').classList.add('hidden');
      document.getElementById('upload-modal').classList.remove('flex');
    }

    function submitNewProject(e) {
      e.preventDefault();
      const title = document.getElementById('m-title').value;
      const category = document.getElementById('m-cat').value;
      const author = document.getElementById('m-author').value;
      const summary = document.getElementById('m-summary').value;
      projects.unshift({
        id: Date.now().toString(),
        title,
        category,
        author: author || 'Nightbrone',
        downloads: 1,
        likes: 1,
        icon: category === 'Shader' ? '✨' : category === 'Resource Pack' ? '🎨' : '📦',
        summary,
        version: '1.21.1',
        size: '6.4 MB'
      });
      closeUploadModal();
      filterProjects();
      alert('Project "' + title + '" published successfully!');
    }
  </script>
</body>
</html>`;

  const copyToClipboard = () => {
    playClickSound();
    navigator.clipboard.writeText(standaloneHtml);
    setCopied(true);
    playSuccessChime();
    setTimeout(() => setCopied(false), 2500);
  };

  const downloadHtmlFile = () => {
    playSuccessChime();
    const blob = new Blob([standaloneHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'superminecraft-curseforge.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div
        className="relative w-full max-w-3xl bg-[#141210] border border-stone-800 rounded-2xl shadow-2xl shadow-black p-6 space-y-4 my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">Standalone Web HTML Code</h3>
              <p className="text-xs text-stone-400">
                Single-file production HTML with Minecraft backgrounds, ember canvas, animations, and CurseForge functionality.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Code View Preview Area */}
        <div className="flex-1 bg-stone-950 border border-stone-800/80 rounded-xl p-4 overflow-auto max-h-96 font-mono text-xs text-stone-300 leading-relaxed">
          <pre className="select-all">
            <code>{standaloneHtml}</code>
          </pre>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-stone-800">
          <div className="text-xs text-stone-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            Single self-contained file (runs locally in any browser with zero dependencies)
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={copyToClipboard}
              className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-stone-200 border border-stone-700/80 rounded-lg text-xs font-semibold flex items-center gap-2 transition cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Entire HTML</span>
                </>
              )}
            </button>

            <button
              onClick={downloadHtmlFile}
              className="px-5 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 rounded-lg text-xs font-bold flex items-center gap-2 shadow-lg shadow-orange-500/20 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .html File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
