import React, { useState } from 'react';
import { X, Download, Heart, Check, Copy, Star, Layers, Cpu, Calendar, ShieldCheck, MessageSquare, Terminal } from 'lucide-react';
import { Project, ProjectVersionFile } from '../types';
import { playClickSound, playHeartPop, playAnvilClink, playSuccessChime } from '../utils/audio';

interface ProjectDetailModalProps {
  project: Project;
  onClose: () => void;
  onToggleLike: (projectId: string) => void;
  onIncrementDownload: (projectId: string) => void;
  onAddReview: (projectId: string, user: string, rating: number, comment: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onToggleLike,
  onIncrementDownload,
  onAddReview,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'files' | 'changelog' | 'reviews'>('overview');
  const [copiedCommand, setCopiedCommand] = useState(false);
  const [downloadingFileId, setDownloadingFileId] = useState<string | null>(null);
  
  // Review form state
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const copyCommand = (cmd: string) => {
    playClickSound();
    navigator.clipboard.writeText(cmd);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 2000);
  };

  const handleDownloadFile = (file: ProjectVersionFile) => {
    playAnvilClink();
    setDownloadingFileId(file.id);
    setTimeout(() => {
      onIncrementDownload(project.id);
      playSuccessChime();
      setDownloadingFileId(null);
    }, 1200);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) return;
    playSuccessChime();
    onAddReview(
      project.id,
      reviewName.trim() || 'MinecraftCrafter',
      reviewRating,
      reviewComment.trim()
    );
    setReviewComment('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div
        className="relative w-full max-w-4xl bg-[#141210] border border-stone-800 rounded-2xl shadow-2xl shadow-black/80 overflow-hidden flex flex-col my-auto max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner with ambient gradient */}
        <div className={`h-36 sm:h-44 w-full bg-gradient-to-r ${project.bannerColor} relative p-6 flex flex-col justify-end border-b border-stone-800`}>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="absolute top-4 right-4 p-2 rounded-xl bg-black/60 hover:bg-black text-stone-300 hover:text-white border border-stone-700/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Project Header Overlay */}
          <div className="flex items-end gap-4 translate-y-8">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-stone-900 border-2 border-stone-700 flex items-center justify-center text-4xl sm:text-5xl shadow-2xl shadow-black">
              {project.icon}
            </div>
            <div className="pb-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30">
                  {project.category}
                </span>
                <span className="text-xs text-stone-400 font-mono">
                  Updated {project.lastUpdated}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {project.title}
              </h2>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="pt-10 px-6 sm:px-8 pb-6 flex-1 overflow-y-auto space-y-6">
          {/* Metadata Subheader */}
          <div className="flex flex-wrap items-center justify-between gap-4 py-3 border-b border-stone-800 text-xs text-stone-300">
            <div className="flex items-center gap-3">
              <span>Author: <strong className="text-white font-bold">{project.author}</strong></span>
              <span className="text-stone-600">·</span>
              <span className="flex items-center gap-1">
                <Download className="w-3.5 h-3.5 text-orange-400" />
                <strong className="text-white tabular-nums">{project.downloads.toLocaleString()}</strong> downloads
              </span>
              <span className="text-stone-600">·</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                Virus Scanned & Verified
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playHeartPop();
                  onToggleLike(project.id);
                }}
                className={`px-3 py-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition cursor-pointer ${
                  project.isLiked
                    ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                    : 'bg-stone-900 border-stone-800 text-stone-300 hover:border-stone-700'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${project.isLiked ? 'fill-rose-400 text-rose-400' : ''}`} />
                <span>{project.likes} Favorites</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 border-b border-stone-800 pb-2">
            {[
              { id: 'overview', label: 'Description & Guide' },
              { id: 'files', label: `Versions (${project.files.length})` },
              { id: 'changelog', label: 'Changelog' },
              { id: 'reviews', label: `Reviews (${project.reviews.length})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  playClickSound();
                  setActiveTab(tab.id as typeof activeTab);
                }}
                className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg transition cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-stone-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6 text-sm text-stone-300">
              <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4">
                <h4 className="text-white font-bold text-base mb-2">About this project</h4>
                <p className="leading-relaxed text-stone-300">{project.description}</p>
              </div>

              {/* Install instructions */}
              <div className="bg-[#191614] border border-orange-500/20 rounded-xl p-4 space-y-3">
                <div className="flex items-center gap-2 text-orange-400 font-bold text-sm">
                  <Terminal className="w-4 h-4" />
                  <span>Installation Guide</span>
                </div>
                <p className="text-xs text-stone-400">
                  {project.category === 'Shader'
                    ? 'Drop the .zip file directly into your ".minecraft/shaderpacks" folder. Requires Iris Shaders or OptiFine.'
                    : project.category === 'Resource Pack'
                    ? 'Place the .zip file into your ".minecraft/resourcepacks" directory and activate it under Minecraft Options > Resource Packs.'
                    : 'Drop the .jar file into your ".minecraft/mods" folder. Ensure you have the compatible mod loader installed.'}
                </p>

                {project.installCommand && (
                  <div className="flex items-center justify-between bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs font-mono">
                    <span className="text-orange-300 select-all">{project.installCommand}</span>
                    <button
                      onClick={() => copyCommand(project.installCommand!)}
                      className="text-stone-400 hover:text-white p-1 rounded hover:bg-stone-800 transition flex items-center gap-1 cursor-pointer"
                      title="Copy command"
                    >
                      {copiedCommand ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span className="text-[10px]">{copiedCommand ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Supported Platforms */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-stone-900/50 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div className="text-xs uppercase font-mono tracking-wider text-stone-400 flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5 text-orange-400" />
                    Supported Mod Loaders
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {project.loaders.map((l) => (
                      <span key={l} className="bg-stone-800 text-stone-200 px-2.5 py-1 rounded-md text-xs font-semibold">
                        {l}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-stone-900/50 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div className="text-xs uppercase font-mono tracking-wider text-stone-400 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    Minecraft Versions
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {project.minecraftVersions.map((v) => (
                      <span key={v} className="bg-stone-800 text-stone-200 px-2.5 py-1 rounded-md text-xs font-semibold">
                        MC {v}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FILES & VERSIONS */}
          {activeTab === 'files' && (
            <div className="space-y-3">
              <p className="text-xs text-stone-400">
                Direct build artifacts available for immediate download:
              </p>
              {project.files.map((file) => (
                <div
                  key={file.id}
                  className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-stone-700 transition"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{file.versionName}</span>
                      <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded font-bold">
                        {file.releaseType}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 text-xs text-stone-400 font-mono">
                      <span>{file.fileName}</span>
                      <span>·</span>
                      <span>MC {file.gameVersion}</span>
                      <span>·</span>
                      <span>{file.fileSize}</span>
                      <span>·</span>
                      <span>{file.uploadDate}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDownloadFile(file)}
                    disabled={downloadingFileId === file.id}
                    className="w-full sm:w-auto px-4 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold text-xs rounded-lg flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {downloadingFileId === file.id ? (
                      <>
                        <Download className="w-3.5 h-3.5 animate-bounce" />
                        Downloading...
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" />
                        Download ({file.fileSize})
                      </>
                    )}
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: CHANGELOG */}
          {activeTab === 'changelog' && (
            <div className="space-y-4">
              {project.changelog.map((log) => (
                <div key={log.version} className="bg-stone-900/50 border border-stone-800 rounded-xl p-4 space-y-2">
                  <div className="flex items-center justify-between border-b border-stone-800 pb-2">
                    <span className="text-orange-400 font-bold text-sm">{log.version}</span>
                    <span className="text-xs text-stone-400 flex items-center gap-1 font-mono">
                      <Calendar className="w-3 h-3" />
                      {log.date}
                    </span>
                  </div>
                  <ul className="list-disc list-inside text-xs text-stone-300 space-y-1">
                    {log.notes.map((note, idx) => (
                      <li key={idx} className="leading-relaxed">{note}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: REVIEWS */}
          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Existing Reviews */}
              <div className="space-y-3">
                {project.reviews.length === 0 ? (
                  <p className="text-xs text-stone-400 italic">No reviews yet. Be the first to leave one!</p>
                ) : (
                  project.reviews.map((rev) => (
                    <div key={rev.id} className="bg-stone-900/50 border border-stone-800 rounded-xl p-3.5 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white">{rev.user}</span>
                        <div className="flex items-center text-amber-400">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-amber-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-stone-300">{rev.comment}</p>
                      <span className="text-[10px] text-stone-400 font-mono">{rev.date}</span>
                    </div>
                  ))
                )}
              </div>

              {/* Add Review Form */}
              <form onSubmit={handleReviewSubmit} className="bg-stone-900/90 border border-stone-800 rounded-xl p-4 space-y-3">
                <h5 className="text-xs font-bold uppercase tracking-wider text-orange-400 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" />
                  Leave a Review
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Your Gamertag (e.g. Steve_Craft)"
                    value={reviewName}
                    onChange={(e) => setReviewName(e.target.value)}
                    className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-400">Rating:</span>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(Number(e.target.value))}
                      className="bg-stone-950 border border-stone-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                    >
                      <option value={5}>⭐⭐⭐⭐⭐ (5/5)</option>
                      <option value={4}>⭐⭐⭐⭐ (4/5)</option>
                      <option value={3}>⭐⭐⭐ (3/5)</option>
                      <option value={2}>⭐⭐ (2/5)</option>
                      <option value={1}>⭐ (1/5)</option>
                    </select>
                  </div>
                </div>

                <textarea
                  rows={2}
                  placeholder="Share your experience with this mod or pack..."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-orange-500"
                  required
                />

                <div className="flex items-center justify-between">
                  {reviewSubmitted ? (
                    <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Review submitted!
                    </span>
                  ) : <span />}
                  <button
                    type="submit"
                    className="px-4 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold text-xs rounded-lg transition cursor-pointer"
                  >
                    Post Review
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
