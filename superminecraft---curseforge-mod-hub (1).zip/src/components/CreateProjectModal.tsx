import React, { useState } from 'react';
import { X, Plus, Sparkles, Check, Upload, Package } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Project, ModLoader } from '../types';
import { playClickSound, playSuccessChime } from '../utils/audio';

interface CreateProjectModalProps {
  onClose: () => void;
  onCreate: (newProject: Project) => void;
}

const EMOJI_ICONS = ['📦', '✨', '🎨', '⚔️', '⛏️', '🛡️', '💎', '🚀', '🧪', '🔮', '🐉', '🏹', '📜', '🧭'];

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  onClose,
  onCreate,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'Mod' | 'Resource Pack' | 'Shader' | 'Modpack'>('Mod');
  const [author, setAuthor] = useState('Nightbrone');
  const [summary, setSummary] = useState('');
  const [description, setDescription] = useState('');
  const [version, setVersion] = useState('1.21.1');
  const [loaders, setLoaders] = useState<ModLoader[]>(['NeoForge', 'Fabric']);
  const [selectedIcon, setSelectedIcon] = useState('📦');
  const [tagsInput, setTagsInput] = useState('Gameplay, Utility, Tricky Trials');

  const toggleLoader = (loader: ModLoader) => {
    if (loaders.includes(loader)) {
      if (loaders.length > 1) {
        setLoaders(loaders.filter((l) => l !== loader));
      }
    } else {
      setLoaders([...loaders, loader]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !summary.trim()) return;

    playSuccessChime();

    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f97316', '#a855f7', '#22c55e', '#38bdf8'],
      });
    } catch {
      // Safe fallback
    }

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);

    const newProject: Project = {
      id: 'proj-' + Date.now(),
      title: title.trim(),
      category,
      summary: summary.trim(),
      description: description.trim() || summary.trim(),
      author: author.trim() || 'Nightbrone',
      downloads: 1,
      likes: 1,
      isLiked: true,
      icon: selectedIcon,
      bannerColor:
        category === 'Shader'
          ? 'from-cyan-600/30 to-stone-900'
          : category === 'Resource Pack'
          ? 'from-emerald-600/30 to-stone-900'
          : category === 'Modpack'
          ? 'from-purple-600/30 to-stone-900'
          : 'from-orange-600/30 to-stone-900',
      minecraftVersions: [version],
      loaders,
      lastUpdated: 'Just now',
      fileSize: '5.2 MB',
      tags: tags.length > 0 ? tags : ['Minecraft', category],
      installCommand: `/curseforge install ${title.toLowerCase().replace(/\s+/g, '-')}`,
      files: [
        {
          id: 'file-' + Date.now(),
          versionName: `${title.trim()} v1.0.0 Release`,
          gameVersion: version,
          loader: loaders,
          releaseType: 'Release',
          fileSize: '5.2 MB',
          uploadDate: 'Today',
          downloads: 1,
          fileName: `${title.trim().replace(/\s+/g, '_')}-${version}-1.0.jar`,
        },
      ],
      changelog: [
        {
          version: 'v1.0.0',
          date: 'Today',
          notes: ['Initial public release on SuperMinecraft platform!'],
        },
      ],
      reviews: [
        {
          id: 'rev-init',
          user: author.trim(),
          rating: 5,
          date: 'Just now',
          comment: 'Uploaded successfully! Tested and verified on Minecraft ' + version,
        },
      ],
    };

    onCreate(newProject);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div
        className="relative w-full max-w-2xl bg-[#141210] border border-stone-800 rounded-2xl shadow-2xl shadow-black p-6 space-y-5 my-auto max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-white">Create New Project</h3>
              <p className="text-xs text-stone-400">Publish a Minecraft mod, resource pack, or shader to SuperMinecraft</p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Submission Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Title & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2 space-y-1">
              <label className="font-semibold text-stone-300">Project Title *</label>
              <input
                type="text"
                required
                placeholder="e.g. Netherite Machinery & Energy"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
              />
            </div>
            <div className="space-y-1">
              <label className="font-semibold text-stone-300">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
              >
                <option value="Mod">📦 Mod</option>
                <option value="Resource Pack">🎨 Resource Pack</option>
                <option value="Shader">✨ Shader</option>
                <option value="Modpack">⚔️ Modpack</option>
              </select>
            </div>
          </div>

          {/* Author & Version */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="font-semibold text-stone-300">Creator / Author Name</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  placeholder="Author name"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  className="flex-1 bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
                />
              </div>
              <div className="flex gap-1 pt-1">
                {['Nightbrone', 'Didula48', 'voidstriker'].map((creator) => (
                  <button
                    key={creator}
                    type="button"
                    onClick={() => setAuthor(creator)}
                    className="text-[10px] text-stone-400 bg-stone-900 hover:bg-stone-800 hover:text-orange-400 px-2 py-0.5 rounded cursor-pointer transition"
                  >
                    +{creator}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="font-semibold text-stone-300">Primary Minecraft Version</label>
              <select
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
              >
                <option value="1.21.1">1.21.1 (Tricky Trials)</option>
                <option value="1.20.4">1.20.4</option>
                <option value="1.19.4">1.19.4</option>
                <option value="1.19.2">1.19.2</option>
                <option value="1.16.5">1.16.5</option>
              </select>
            </div>
          </div>

          {/* Mod Loaders */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-300">Supported Mod Loaders</label>
            <div className="flex flex-wrap gap-2">
              {(['Forge', 'Fabric', 'NeoForge', 'Quilt'] as ModLoader[]).map((loader) => (
                <button
                  type="button"
                  key={loader}
                  onClick={() => toggleLoader(loader)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                    loaders.includes(loader)
                      ? 'bg-orange-500/20 border-orange-500/50 text-orange-400'
                      : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700'
                  }`}
                >
                  {loaders.includes(loader) && <Check className="w-3 h-3 text-orange-400" />}
                  {loader}
                </button>
              ))}
            </div>
          </div>

          {/* Icon Selector */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-300">Choose Mod Icon</label>
            <div className="flex flex-wrap gap-2 p-2 bg-stone-950 border border-stone-800 rounded-xl">
              {EMOJI_ICONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setSelectedIcon(emoji)}
                  className={`w-9 h-9 text-xl rounded-lg flex items-center justify-center transition cursor-pointer ${
                    selectedIcon === emoji
                      ? 'bg-orange-500/30 border border-orange-500/80 scale-110'
                      : 'hover:bg-stone-800 border border-transparent'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Short Summary */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-300">Short Summary *</label>
            <input
              type="text"
              required
              placeholder="A snappy 1-sentence hook explaining what your project adds..."
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Full Description */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-300">Full Description</label>
            <textarea
              rows={3}
              placeholder="Detailed description, crafting recipes, features, and keybindings..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Tags */}
          <div className="space-y-1">
            <label className="font-semibold text-stone-300">Tags (comma-separated)</label>
            <input
              type="text"
              placeholder="e.g. Technology, Dungeons, Magic, Food"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              className="w-full bg-stone-950 border border-stone-800 rounded-lg p-2.5 text-stone-100 text-sm focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-stone-800">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onClose();
              }}
              className="px-4 py-2 text-stone-400 hover:text-white bg-stone-900 hover:bg-stone-800 rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-orange-500 hover:bg-orange-400 text-stone-950 font-bold rounded-lg shadow-lg shadow-orange-500/20 flex items-center gap-2 transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Publish Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
