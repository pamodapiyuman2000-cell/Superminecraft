import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
  fadeSpeed: number;
  hue: number;
  life: number;
  maxLife: number;
}

export const EmberCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particle pool
    const particleCount = 45;
    const particles: Particle[] = [];

    const createParticle = (randomY = false): Particle => {
      const maxLife = 120 + Math.random() * 160;
      return {
        x: Math.random() * width,
        y: randomY ? Math.random() * height : height + 10 + Math.random() * 20,
        size: 1.2 + Math.random() * 2.8,
        speedY: 0.5 + Math.random() * 1.2,
        speedX: (Math.random() - 0.5) * 0.6,
        opacity: 0.1 + Math.random() * 0.7,
        fadeSpeed: 0.003 + Math.random() * 0.005,
        hue: 24 + Math.random() * 26, // Warm orange to golden yellow (24-50)
        life: 0,
        maxLife,
      };
    };

    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle(true));
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.life++;
        p.y -= p.speedY;
        p.x += p.speedX + Math.sin(p.life * 0.03) * 0.4;

        // Fade calculation
        const progress = p.life / p.maxLife;
        let currentOpacity = p.opacity;
        if (progress > 0.7) {
          currentOpacity = p.opacity * (1 - (progress - 0.7) / 0.3);
        }

        ctx.save();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 95%, 55%, ${Math.max(0, currentOpacity)})`;
        ctx.shadowColor = `hsl(${p.hue}, 100%, 50%)`;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.restore();

        if (p.y < -20 || p.life >= p.maxLife) {
          particles[i] = createParticle(false);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-0 h-full w-full opacity-60 mix-blend-screen"
      aria-hidden="true"
    />
  );
};
