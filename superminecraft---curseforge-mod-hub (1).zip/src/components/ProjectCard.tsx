import React, { useState } from 'react';
import { Download, Heart, ExternalLink, Check, Layers, Cpu, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Project } from '../types';
import { playClickSound, playHeartPop, playAnvilClink, playSuccessChime } from '../utils/audio';

interface ProjectCardProps {
  project: Project;
  onSelect: (project: Project) => void;
  onToggleLike: (projectId: string) => void;
  onIncrementDownload: (projectId: string) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onSelect,
  onToggleLike,
  onIncrementDownload,
}) => {
  const [downloadProgress, setDownloadProgress] = useState<number | null>(null);
  const [downloadCompleted, setDownloadCompleted] = useState(false);

  const formatDownloads = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (downloadProgress !== null) return; // already downloading

    playAnvilClink();
    setDownloadProgress(0);

    const interval = setInterval(() => {
      setDownloadProgress((prev) => {
        if (prev === null) return 0;
        if (prev >= 100) {
          clearInterval(interval);
          setDownloadCompleted(true);
          onIncrementDownload(project.id);
          playSuccessChime();

          // Fire subtle confetti burst
          try {
            confetti({
              particleCount: 35,
              spread: 60,
              origin: { y: 0.8 },
              colors: ['#f97316', '#fbbf24', '#22c55e'],
            });
          } catch {
            // Safe fallback
          }

          setTimeout(() => {
            setDownloadCompleted(false);
            setDownloadProgress(null);
          }, 3000);
          return 100;
        }
        return prev + 18;
      });
    }, 70);
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    playHeartPop();
    onToggleLike(project.id);
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Mod':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'Shader':
        return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
      case 'Resource Pack':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'Modpack':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/30';
      default:
        return 'text-orange-400 bg-orange-500/10 border-orange-500/30';
    }
  };

  return (
    <div
      onClick={() => {
        playClickSound();
        onSelect(project);
      }}
      className="group relative bg-[#171412]/90 hover:bg-[#1f1b18]/95 border border-stone-800/80 hover:border-orange-500/50 rounded-2xl p-4 sm:p-5 transition-all duration-200 shadow-xl shadow-black/40 hover:shadow-2xl hover:shadow-orange-500/10 cursor-pointer overflow-hidden transform hover:-translate-y-1"
    >
      {/* Subtle top edge glow on hover */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-orange-500/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="flex flex-col sm:flex-row items-start gap-4">
        {/* Project Thumbnail / Icon */}
        <div className="relative shrink-0 w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-stone-900 border border-stone-700/60 flex items-center justify-center text-3xl sm:text-4xl shadow-inner group-hover:scale-105 transition-transform duration-200">
          <span className="select-none">{project.icon}</span>
          <div className="absolute -bottom-1 -right-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-stone-800/90 border border-stone-700 text-stone-300">
            {project.fileSize}
          </div>
        </div>

        {/* Project Content Info */}
        <div className="flex-1 min-w-0 w-full space-y-2">
          {/* Header Row: Title & Action Badges */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-bold text-lg text-white group-hover:text-orange-400 transition-colors tracking-tight truncate">
                {project.title}
              </h3>
              <span
                className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${getCategoryColor(
                  project.category
                )}`}
              >
                {project.category}
              </span>
            </div>

            <div className="flex items-center gap-2 ml-auto">
              <button
                onClick={handleLike}
                title={project.isLiked ? 'Unlike' : 'Favorite project'}
                className={`p-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                  project.isLiked
                    ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                    : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-rose-400 hover:border-stone-700'
                }`}
              >
                <Heart
                  className={`w-3.5 h-3.5 ${
                    project.isLiked ? 'fill-rose-400 text-rose-400 scale-110' : ''
                  } transition-transform`}
                />
                <span className="font-mono text-[11px]">{project.likes}</span>
              </button>
            </div>
          </div>

          {/* Clean author metadata */}
          <div className="flex items-center gap-2 text-xs text-stone-400">
            <span>By <strong className="text-stone-300 font-semibold">{project.author}</strong></span>
            <span aria-hidden="true" className="text-stone-600">·</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-stone-400" />
              {project.lastUpdated}
            </span>
          </div>

          {/* Summary */}
          <p className="text-xs sm:text-sm text-stone-300 line-clamp-2 leading-relaxed">
            {project.summary}
          </p>

          {/* Tags & Loaders */}
          <div className="pt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
            {project.loaders.map((loader) => (
              <span
                key={loader}
                className="bg-stone-900/90 border border-stone-800 text-stone-300 px-2 py-0.5 rounded text-[11px] font-medium flex items-center gap-1"
              >
                <Cpu className="w-2.5 h-2.5 text-orange-400" />
                {loader}
              </span>
            ))}
            <span className="bg-stone-900/90 border border-stone-800 text-stone-300 px-2 py-0.5 rounded text-[11px] font-medium flex items-center gap-1">
              <Layers className="w-2.5 h-2.5 text-cyan-400" />
              {project.minecraftVersions[0]}
            </span>
            {project.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-stone-400 bg-stone-950/60 px-2 py-0.5 rounded text-[10px]"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Bottom Action Bar: Downloads count + Download Button + Details */}
          <div className="pt-3 border-t border-stone-800/60 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-4 text-xs font-mono text-stone-400">
              <div className="flex items-center gap-1.5 text-stone-300">
                <Download className="w-3.5 h-3.5 text-orange-400" />
                <span className="font-bold text-white tabular-nums">
                  {formatDownloads(project.downloads)}
                </span>
                <span className="text-stone-400 text-[11px]">downloads</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  playClickSound();
                  onSelect(project);
                }}
                className="px-3 py-1.5 text-xs text-stone-300 hover:text-white bg-stone-900 hover:bg-stone-800 border border-stone-800 hover:border-stone-700 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <ExternalLink className="w-3 h-3 text-stone-400" />
                Details
              </button>

              <button
                type="button"
                onClick={handleDownload}
                disabled={downloadProgress !== null}
                className={`relative px-4 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all shadow-md cursor-pointer overflow-hidden ${
                  downloadCompleted
                    ? 'bg-emerald-600 text-white'
                    : downloadProgress !== null
                    ? 'bg-stone-800 text-orange-400 border border-orange-500/40'
                    : 'bg-orange-500 hover:bg-orange-400 text-stone-950 shadow-orange-500/20 hover:shadow-orange-500/30'
                }`}
              >
                {/* Progress bar fill */}
                {downloadProgress !== null && !downloadCompleted && (
                  <div
                    className="absolute inset-0 bg-orange-500/20 transition-all duration-100"
                    style={{ width: `${downloadProgress}%` }}
                  />
                )}

                <span className="relative z-10 flex items-center gap-1.5">
                  {downloadCompleted ? (
                    <>
                      <Check className="w-3.5 h-3.5" /> Installed!
                    </>
                  ) : downloadProgress !== null ? (
                    <>
                      <Download className="w-3.5 h-3.5 animate-bounce" /> {downloadProgress}%
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" /> Download
                    </>
                  )}
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
