import React from 'react';
import { Sparkles, Compass, Shield, ArrowRight, Flame } from 'lucide-react';
import { playClickSound, playSuccessChime } from '../utils/audio';

interface SplashScreenProps {
  onEnter: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onEnter }) => {
  const handleStart = () => {
    playClickSound();
    setTimeout(() => {
      playSuccessChime();
      onEnter();
    }, 150);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#070504] px-4 overflow-hidden select-none">
      {/* Dynamic ambient background glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.18)_0,rgba(12,10,9,0.95)_70%)] pointer-events-none" />
      
      {/* Minecraft styled grid backdrop */}
      <div className="absolute inset-0 opacity-25 pointer-events-none bg-[radial-gradient(#ea580c_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="relative z-10 text-center max-w-2xl mx-auto space-y-7 px-4">
        {/* Animated Brand Flame / Anvil Logo */}
        <div className="relative mx-auto w-24 h-24 mb-3">
          <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-red-500 opacity-75 blur-md animate-pulse" />
          <div className="relative w-full h-full bg-[#1c1917] border-2 border-orange-500/50 rounded-2xl flex items-center justify-center shadow-2xl shadow-orange-500/30 group transform hover:scale-105 transition-transform duration-300">
            <Flame className="w-12 h-12 text-orange-400 fill-orange-500/20 animate-bounce" />
            <div className="absolute -bottom-1 -right-1 bg-amber-500 text-stone-950 p-1 rounded-md text-[10px] font-black uppercase tracking-wider">
              Forge
            </div>
          </div>
        </div>

        {/* Creator Attribution Badges */}
        <div className="space-y-2">
          <p className="text-xs font-mono uppercase tracking-[0.35em] text-orange-400 font-semibold flex items-center justify-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 inline" />
            Architected & Created By
            <Sparkles className="w-3.5 h-3.5 text-amber-400 inline" />
          </p>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight flex flex-wrap items-center justify-center gap-2 sm:gap-3 text-white">
            <span className="bg-gradient-to-r from-purple-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent hover:brightness-125 transition-all">
              Nightbrone
            </span>
            <span className="text-stone-600 font-light select-none">•</span>
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-400 bg-clip-text text-transparent hover:brightness-125 transition-all">
              Didula48
            </span>
            <span className="text-stone-600 font-light select-none">•</span>
            <span className="bg-gradient-to-r from-amber-400 via-orange-300 to-amber-400 bg-clip-text text-transparent hover:brightness-125 transition-all">
              voidstriker
            </span>
          </h1>
        </div>

        {/* Brand Tagline */}
        <div className="space-y-2 max-w-lg mx-auto">
          <p className="text-base sm:text-lg text-stone-300 font-medium leading-relaxed">
            Next-generation CurseForge inspired database hub for Minecraft.
          </p>
          <p className="text-xs sm:text-sm text-stone-400 font-normal">
            Discover mods, high-fidelity resource packs, shaders, and modpacks with instant live download simulation and community uploads.
          </p>
        </div>

        {/* Feature Highlights Pills */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-stone-400 pt-1">
          <span className="flex items-center gap-1.5 bg-stone-900/80 border border-stone-800 px-3 py-1.5 rounded-lg text-stone-300">
            <Compass className="w-3.5 h-3.5 text-orange-400" />
            1.21.x Tricky Trials Ready
          </span>
          <span className="flex items-center gap-1.5 bg-stone-900/80 border border-stone-800 px-3 py-1.5 rounded-lg text-stone-300">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Forge • Fabric • NeoForge
          </span>
          <span className="flex items-center gap-1.5 bg-stone-900/80 border border-stone-800 px-3 py-1.5 rounded-lg text-stone-300">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            Live HTML Export
          </span>
        </div>

        {/* Enter Dashboard Action Button */}
        <div className="pt-4">
          <button
            onClick={handleStart}
            className="group relative inline-flex items-center gap-3 px-9 py-4 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 text-stone-950 font-bold text-base rounded-xl shadow-xl shadow-orange-500/30 transform hover:-translate-y-1 active:translate-y-0 transition-all duration-200 cursor-pointer overflow-hidden focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 focus:ring-offset-stone-950"
          >
            <span className="relative z-10 flex items-center gap-2 tracking-wide font-extrabold">
              Explore SuperMinecraft
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform" />
            </span>
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>
        </div>

        <p className="text-[11px] text-stone-400 font-mono pt-2">
          Press to launch the mod database interface
        </p>
      </div>
    </div>
  );
};
